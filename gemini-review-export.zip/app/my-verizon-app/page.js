import Link from 'next/link';

export default function VerizonCaseStudy() {
  return (
    <div className="py-16 md:py-24 max-w-3xl mx-auto tracking-tight">
      
      {/* Back Link */}
      <div className="mb-12">
        <Link href="/" className="text-xs font-mono text-stone-500 hover:text-stone-900 transition-colors flex items-center gap-2 group">
          <span className="transition-transform group-hover:-translate-x-0.5">←</span> Back to featured work
        </Link>
      </div>

      {/* Header Block */}
      <header className="mb-16">
        <div className="flex items-center gap-4 text-xs font-mono text-stone-500/80 font-bold uppercase tracking-[0.2em] mb-4">
          <span>Project Pathfinder</span>
          <span className="text-stone-400/60">•</span>
          <span>My Verizon App</span>
        </div>
        <h1 className="text-3xl md:text-4xl font-light leading-tight mb-6">
          Skim, Dip, Dive: Re-architecting the L1 mobile experience
        </h1>
        <p className="text-base md:text-lg font-normal leading-relaxed text-stone-600/90">
          How a centralized navigation framework transformed a dense, fragmented application into an elegant pathfinder system. This initiative drove a 60% engagement lift while protecting long-term design governance.
        </p>
      </header>

      {/* Hard Metrics Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-8 border-y border-stone-400/50 py-10 mb-16 text-center sm:text-left">
        <div>
          <span className="text-4xl font-light">60%</span>
          <p className="text-xs font-mono mt-2 uppercase tracking-wider font-bold text-stone-500">Monthly Engagement</p>
          <p className="text-xs font-normal mt-1 text-stone-600/80">Sustained across active app users.</p>
        </div>
        <div>
          <span className="text-4xl font-light">4.7★</span>
          <p className="text-xs font-mono mt-2 uppercase tracking-wider font-bold text-stone-500">iOS App Store Rating</p>
          <p className="text-xs font-normal mt-1 text-stone-600/80">Accompanied by 4.8 on Google Play.</p>
        </div>
        <div>
          <span className="text-4xl font-light">10M+</span>
          <p className="text-xs font-mono mt-2 uppercase tracking-wider font-bold text-stone-500">Ecosystem Impressions</p>
          <p className="text-xs font-normal mt-1 text-stone-600/80">Spurring 1M+ unique ecosystem sub-visits.</p>
        </div>
      </section>

      {/* Act I: The Catalyst */}
      <section className="mb-12">
        <h3 className="section-label">The Catalyst</h3>
        <div className="space-y-4 text-sm md:text-base font-normal leading-relaxed">
          <p>
            The legacy My Verizon application suffered from its own success. As an incredibly dense product handling everything from billing to connected home device management, it had gradually become an aggregation point for competing internal business priorities. 
          </p>
          <p>
            With no centralized hierarchy governing the Level 1 (L1) experience, new features were constantly surfaced at the top layer. This rapid feature bloat obscured intuitive user paths, suppressed core digital revenue discovery, and significantly amplified customer contact center drivers.
          </p>
        </div>
      </section>

      {/* VISUAL INSERT 1: RECONFIGURED L1 ENTRY (SKIM LAYER) */}
      <section className="mb-20">
        <div className="bg-stone-300/30 border border-stone-400/20 rounded-2xl p-6 md:p-12 flex flex-col items-center justify-center gap-4">
          <div className="w-full max-w-[250px] aspect-[9/19] rounded-[1.5rem] overflow-hidden shadow-2xl shadow-stone-950/20 border border-stone-400/40 bg-white">
            <img 
              src="/images/verizon/MVA Screen 2.png" 
              alt="My Verizon App L1 Pathfinder Dashboard"
              className="h-full w-full object-cover object-top block"
            />
          </div>
          <span className="text-xs font-mono text-stone-500 italic text-center max-w-md mt-4">
            Figure 1.0: Reconfigured L1 Pathfinder dashboard balancing top-level utility states, account actions, and billing transparency inside an intentional scanning layout.
          </span>
        </div>
      </section>

      {/* Act II: The Information Processing Strategy */}
      <section className="mb-12">
        <h3 className="section-label">The Framework as a Governance Model</h3>
        <div className="space-y-4 text-sm md:text-base font-normal leading-relaxed">
          <p>
            To address this, we introduced the <strong className="font-semibold">"Skim, Dip, Dive"</strong> architecture. Instead of treating the home dashboard as a final destination, we repositioned it as an information processing strategy. This allowed customers to digest the sheer breadth of the product one intentional step at a time.
          </p>
          <p>
            Beyond a clean interaction loop, the framework served a vital operational purpose: <strong className="font-semibold">product governance</strong>. By codifying strict boundaries for what constituted a "Skim" element versus a "Dive" flow, we provided cross-functional teams with a clear, objective framework to evaluate and slot new features without degrading the baseline L1 clarity.
          </p>
        </div>
      </section>

      {/* Framework Blueprint Visualization diagram */}
      <section className="mb-12">
        <div className="w-full py-12 bg-stone-400/30 border border-stone-400/50 rounded-2xl flex items-center justify-center gap-6 md:gap-12 font-mono text-xs text-stone-700 shadow-inner px-4">
          <div className="px-5 py-3 bg-stone-100 border border-stone-400/40 rounded-xl shadow-sm text-center min-w-[90px]">
            <span className="block font-bold">Skim</span>
            <span className="text-[10px] text-stone-500 font-semibold mt-0.5 block">L1 Harmony</span>
          </div>
          <span className="font-bold text-stone-400">→</span>
          <div className="px-5 py-3 bg-stone-100 border border-stone-400/40 rounded-xl shadow-sm text-center min-w-[90px]">
            <span className="block font-bold">Dip</span>
            <span className="text-[10px] text-stone-500 font-semibold mt-0.5 block">Contextual Drill</span>
          </div>
          <span className="font-bold text-stone-400">→</span>
          <div className="px-5 py-3 bg-stone-100 border border-stone-400/40 rounded-xl shadow-sm text-center min-w-[90px]">
            <span className="block font-bold">Dive</span>
            <span className="text-[10px] text-stone-500 font-semibold mt-0.5 block">Task Completion</span>
          </div>
        </div>
      </section>

      {/* VISUAL INSERT 2: THE CONTEXTUAL DRILLDOWN (DIP & DIVE LAYERS) */}
      <section className="mb-20">
        <div className="bg-stone-300/30 border border-stone-400/20 rounded-2xl p-6 md:p-12 flex flex-col gap-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start justify-items-center">
            
            {/* Left Phone: Dip View */}
            <div className="w-full max-w-[250px] aspect-[9/19] rounded-[1.5rem] overflow-hidden shadow-2xl shadow-stone-950/20 border border-stone-400/40 bg-white">
              <img 
                src="/images/verizon/IMG_4843.PNG" 
                alt="Verizon Device Detail Flow (Dip Layer)"
                className="h-full w-full object-cover object-top block"
              />
            </div>
            
            {/* Right Phone: Dive View */}
            <div className="w-full max-w-[250px] aspect-[9/19] rounded-[1.5rem] overflow-hidden shadow-2xl shadow-stone-950/20 border border-stone-400/40 bg-white">
              <img 
                src="/images/verizon/IMG_4844.PNG" 
                alt="Verizon Usage Metrics Utilization Chart (Dive Layer)"
                className="h-full w-full object-cover object-top block"
              />
            </div>

          </div>
          <span className="text-xs font-mono text-stone-500 italic text-center max-w-lg mx-auto mt-2">
            Figure 1.1: Vertical navigation patterns translating standard links into high-context components. Inquire actions (Dip) map details instantly to granular, sub-tier tracking states (Dive).
          </span>
        </div>
      </section>

      {/* Act III: Cross-Functional Alignment */}
      <section className="mb-16">
        <h3 className="section-label">Cross-Functional Negotiation</h3>
        <p className="text-sm md:text-base font-normal leading-relaxed mb-6 text-stone-600/90">
          True design leadership means delivering complex systems inside rigid organizational realities. Executing Project Pathfinder required careful, strategic diplomacy across three pillars:
        </p>
        <div className="grid grid-cols-1 gap-6 text-sm">
          <div className="p-5 bg-stone-100/90 border border-stone-400/40 rounded-xl shadow-sm">
            <span className="font-bold block mb-1">Product Management Alignment</span>
            <p className="font-normal text-stone-600/90 leading-relaxed">Navigated historical, feature-dense product roadmaps by translating UX improvements directly into shared growth metrics, shifting the collaborative focus from feature volume to structural clarity.</p>
          </div>
          <div className="p-5 bg-stone-100/90 border border-stone-400/40 rounded-xl shadow-sm">
            <span className="font-bold block mb-1">Design System Stewardship</span>
            <p className="font-normal text-stone-600/90 leading-relaxed">Collaborated with global system maintainers to advocate for contextual patterns, validating specific system departures where localized nuance was required to enhance scannability.</p>
          </div>
          <div className="p-5 bg-stone-100/90 border border-stone-400/40 rounded-xl shadow-sm">
            <span className="font-bold block mb-1">Engineering Partnership</span>
            <p className="font-normal text-stone-600/90 leading-relaxed">Partnered deeply with engineering teams to explore structural frontend solutions that stepped outside conventional layout boundaries, keeping performance lightweight and fluid.</p>
          </div>
        </div>
      </section>

      {/* Learnings & Next Steps */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-12 text-sm font-normal leading-relaxed border-t border-stone-400/40 pt-12">
        <div>
          <h4 className="text-xs font-mono uppercase text-stone-500 font-bold mb-4 tracking-wider">// Key Takeaways</h4>
          <ul className="space-y-3 text-stone-600/90 text-xs md:text-sm">
            <li>• <strong className="font-semibold">Hierarchy is a growth lever:</strong> Reducing top-level noise consistently maximizes downstream completion.</li>
            <li>• <strong className="font-semibold">Shared models reduce friction:</strong> Frameworks unify cross-functional teams and dramatically eliminate competing priorities.</li>
            <li>• <strong className="font-semibold">Simplicity requires protection:</strong> Without active governance structures, interface complexity inevitably sneaks back over time.</li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-mono uppercase text-stone-500 font-bold mb-4 tracking-wider">// Strategic Horizon</h4>
          <ul className="space-y-3 text-stone-600/90 text-xs md:text-sm">
            <li>1. Monitor ongoing behavioral data streams to iteratively refine features appearing on L1 based on user intent models.</li>
            <li>2. Evolve the modular layout to better support personalized, contextual user situations without fracturing the core visual clarity.</li>
            <li>3. Propagate the skim-dip-dive framework across complementary platforms to lock down absolute ecosystem consistency.</li>
          </ul>
        </div>
      </section>

    </div>
  );
}